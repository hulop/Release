# NavCogMapEditor
=======

This is a HTML5 tool to edit map data for NavCog app.

Please check "Quick Start Guide" in [00Readme](../00Readme) project for usage of the map tool.


## Development

Current implementation uses browser local storage to store map data. It could not exceed 10MB in total.

### Prerequisites

/editor/oss/
[MarkerWithLabel.js](http://google-maps-utility-library-v3.googlecode.com/svn/tags/markerwithlabel/1.1.9/markerwithlabel/src/markerwithlabel.js)

----
## About
[About HULOP](https://github.com/hulop/00Readme)

## License
[MIT](http://opensource.org/licenses/MIT)
