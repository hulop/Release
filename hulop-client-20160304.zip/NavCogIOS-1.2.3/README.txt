This library is intended solely for use with an Apple iOS product and intended
to be used in conjunction with officially licensed Apple development tools.